%%%% Dynamics Controller
function tau_ff = ff_0(th_curr, th_d_curr, th_des, th_d_des, th_dd_des)
    tau_ff = [0; 0];
end