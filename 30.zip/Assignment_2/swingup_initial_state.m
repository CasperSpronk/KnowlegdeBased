function x0 = swingup_initial_state()
    % Setup starting state
    x0=[2*rand()-1, 2*rand()-1];
end
